#include "pithon.h"

main()
{
   int nullXY, flash=0;

   Init();
   Rand();
   while(true)
   {
      /*================
        �������
        ================*/
      if(flash==8)
      {
         UndrawPoint();
         flash=0;
      }
      else DrawPoint();
      /*================*/
      KeyVector(vector);
      switch(vector)
      {
         case 1: x--; break;
         case 2: x++; break;
         case 3: y--; break;
         case 4: y++; break;
      }
     /* ===========
        ���������
        =========== */
      LastNull();

      nullXY=NullXY();
      if(x!=xR || y!=yR)
      {
         Sdvig();
         massPithon[0][nullXY-1]=x; massPithon[1][nullXY-1]=y;
      }
      else
      {
         massPithon[0][nullXY]=x; massPithon[1][nullXY]=y;       //����
         Rand();
         score++;
      }
      /* ==========
      
         ========== */
      /* ===============
         Game Over
         =============== */
      if(x==0 ) GameOver();
      if(y==0 ) GameOver();
      if(x==81) GameOver();
      if(y==51) GameOver();
      for(int i=0 ; i<nullXY-1 ; i++)          //�������������
      {
         if(massPithon[0][i]==massPithon[0][nullXY-1] && massPithon[1][i]==massPithon[1][nullXY-1]) GameOver();
      }
      /* =============== */
      Draw();
      flash++;
      Sleep(50);
   }
}

void KeyVector(int &Vector)
{
   int k;
   if(kbhit())
   {
      k=getch();
      switch(k)
      {
         case 97 : if(Vector!=2) Vector=1; break;
         case 100: if(Vector!=1) Vector=2; break;
         case 119: if(Vector!=4) Vector=3; break;
         case 115: if(Vector!=3) Vector=4; break;
      }
   }
}

void Init()
{
   _setcursortype(0);
   textmode(C80X50);
   SetConsoleTitle("PITHON");
   _wscroll=0;
}

void Draw()
{
   for(int i=0 ; i<NullXY() ; i++)
   {
      gotoxy(massPithon[0][i],massPithon[1][i]);
      cout<<"*";
   }
   gotoxy(xT,yT); cout<<" ";               //��� ����� LastNull,������ "����"
}

void Sdvig()
{
   for(int i=1 ; i<maxSize ; i++)
   {
      massPithon[1][i-1]=massPithon[1][i];
      massPithon[0][i-1]=massPithon[0][i];
   }
}

int NullXY()
{
   int i;

   for(i=0 ; i<maxSize ; i++) if(!massPithon[0][i]) return i;
   return i;
}

void LastNull()
{
   xT=massPithon[0][0];
   yT=massPithon[1][0];
}

void GameOver()
{
   for(int i=0 ; i<4 ; i++)
   {
      massPithon[1][i]=4;
      massPithon[0][i]=i+1;
   }
   for(int i=4 ; i<maxSize ; i++)
   {
      massPithon[1][i]=0;
      massPithon[0][i]=0;
   }
   x=4; y=4; vector=2;
   Rand();
   clrscr();
   gotoxy(35,22); cout<<"Game Over";
   gotoxy(35,25); cout<<"score: "<<score*100;
   score=0;
   Sleep(5);      //�� ���� �� �����
   while(1)
   {
      if(kbhit())
      {
         clrscr();
         return;
      }
   }
}

void Rand()
{
   bool k=false;

   randomize();
   do
   {
      xR=rand()%100*0.78+1;
      yR=(rand()%100)/2+1;
      for(int i=0 ; i<maxSize ; i++)
      if(xR==massPithon[0][i] && yR==massPithon[1][i]) k=true;
   }
   while(k);
}

void DrawPoint()
{
   gotoxy(xR,yR);cout<<"+";
}

void UndrawPoint()
{
   gotoxy(xR,yR);cout<<" ";
}
